﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CityHash;


namespace hashmaker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string data = "Hello, World!"; // Data to be hashed
            MessageBox.Show(cityhash32(data));
            MessageBox.Show(cityhash64(data));
            MessageBox.Show(cityhash128(data));
            
            
            
            
        }
        static string cityhash32(string input)
        {
            ulong hash = CityHash.CityHash.CityHash32(input);
            return hash.ToString();
        }
        static string cityhash64(string input)
        {
            ulong hash = CityHash.CityHash.CityHash64(input);
            return hash.ToString();
        }
        static string cityhash128(string input)
        {
            uint128 hash = CityHash.CityHash.CityHash128(input);
            return "Low values: "+hash.Low.ToString()+" High values: "+hash.High.ToString();
        }

    }
}
